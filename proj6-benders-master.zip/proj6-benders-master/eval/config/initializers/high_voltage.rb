# frozen_string_literal: true

HighVoltage.configure do |config|
  # if current_user
  #   config.home_page = 'users/'+current_user.id
  # else
  config.home_page = 'home'
  # end
end
