# frozen_string_literal: true

INFO = YAML.load_file(Rails.root.join('config', 'info.yml'))
