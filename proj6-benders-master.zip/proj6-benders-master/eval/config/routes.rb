# frozen_string_literal: true

Rails.application.routes.draw do
  resources :ind_feedbacks
  resources :links
  devise_for :users
  resources :presentations
  resources :users
  resources :feedbacks
end
