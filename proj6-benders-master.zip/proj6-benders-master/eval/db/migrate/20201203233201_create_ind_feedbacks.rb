# frozen_string_literal: true

class CreateIndFeedbacks < ActiveRecord::Migration[6.0]
  def change
    create_table :ind_feedbacks do |t|
      t.integer :presentation_id
      t.integer :user_id
      t.integer :presentation_organization
      t.integer :presentation_visuals
      t.integer :presentation_content
      t.integer :presentation_delivery
      t.integer :presentation_overall
      t.string :comments
      t.integer :fscore
      t.integer :instr_id

      t.timestamps
    end
  end
end
