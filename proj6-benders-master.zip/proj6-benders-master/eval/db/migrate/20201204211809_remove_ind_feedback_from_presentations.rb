# frozen_string_literal: true

class RemoveIndFeedbackFromPresentations < ActiveRecord::Migration[6.0]
  def change
    remove_column :presentations, :ind_feedback, :integer
  end
end
