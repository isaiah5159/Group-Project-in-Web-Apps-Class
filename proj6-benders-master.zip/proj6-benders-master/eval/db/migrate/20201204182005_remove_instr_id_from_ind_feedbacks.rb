# frozen_string_literal: true

class RemoveInstrIdFromIndFeedbacks < ActiveRecord::Migration[6.0]
  def change
    remove_column :ind_feedbacks, :instr_id, :integer
  end
end
