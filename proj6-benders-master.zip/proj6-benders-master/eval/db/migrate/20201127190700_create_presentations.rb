# frozen_string_literal: true

class CreatePresentations < ActiveRecord::Migration[6.0]
  def change
    create_table :presentations do |t|
      t.integer :user_id
      t.integer :fscore
      t.string :name

      t.timestamps
    end
  end
end
