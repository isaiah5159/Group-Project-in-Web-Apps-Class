# frozen_string_literal: true

class CreateFeedbacks < ActiveRecord::Migration[6.0]
  def change
    create_table :feedbacks do |t|
      t.integer :presentation_organization
      t.integer :presentation_visuals
      t.integer :presentation_content
      t.integer :presentation_delivery
      t.integer :presentation_overall
      t.text :comments
      t.integer :perm
      t.integer :presentation_id
      t.integer :user_id

      t.timestamps
    end
  end
end
