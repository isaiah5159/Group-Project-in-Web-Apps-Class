# frozen_string_literal: true

class DropRosters < ActiveRecord::Migration[6.0]
  def change
    drop_table :rosters
  end
end
