# frozen_string_literal: true

class AddIndFeedbackToPresentations < ActiveRecord::Migration[6.0]
  def change
    add_column :presentations, :ind_feedback, :integer
  end
end
