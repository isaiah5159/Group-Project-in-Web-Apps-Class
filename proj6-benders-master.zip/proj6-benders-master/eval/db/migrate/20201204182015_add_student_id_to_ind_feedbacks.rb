# frozen_string_literal: true

class AddStudentIdToIndFeedbacks < ActiveRecord::Migration[6.0]
  def change
    add_column :ind_feedbacks, :student_id, :integer
  end
end
