# frozen_string_literal: true

class RemoveFscoreFromPresentations < ActiveRecord::Migration[6.0]
  def change
    remove_column :presentations, :fscore, :integer
  end
end
