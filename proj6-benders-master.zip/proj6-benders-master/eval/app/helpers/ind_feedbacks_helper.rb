# frozen_string_literal: true

module IndFeedbacksHelper
end
