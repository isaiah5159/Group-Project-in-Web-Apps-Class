# frozen_string_literal: true

module LinksHelper
end
