# frozen_string_literal: true

class Link < ApplicationRecord
  belongs_to :user
  belongs_to :presentation
end
