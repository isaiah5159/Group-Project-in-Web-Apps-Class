# frozen_string_literal: true

class IndFeedback < ApplicationRecord
  belongs_to :user
  belongs_to :presentation

  validates :presentation_organization, presence: true, numericality: { greater_than_or_equal_to: 0, less_than_or_equal_to: 5, only_integer: true }
  validates :presentation_visuals, presence: true, numericality: { greater_than_or_equal_to: 0, less_than_or_equal_to: 5, only_integer: true }
  validates :presentation_content, presence: true, numericality: { greater_than_or_equal_to: 0, less_than_or_equal_to: 5, only_integer: true }
  validates :presentation_delivery, presence: true, numericality: { greater_than_or_equal_to: 0, less_than_or_equal_to: 5, only_integer: true }
  validates :presentation_overall, presence: true, numericality: { greater_than_or_equal_to: 0, less_than_or_equal_to: 5, only_integer: true }
end
