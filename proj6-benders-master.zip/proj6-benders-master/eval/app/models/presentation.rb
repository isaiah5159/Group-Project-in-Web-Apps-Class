# frozen_string_literal: true

# include the has_many attributes for presentation and validations
class Presentation < ApplicationRecord
  has_many :feedbacks
  has_many :ind_feedbacks
  has_many :links
  has_many :users, through: :links

  validates :name, presence: true
  validates :users, presence: true
end
