# frozen_string_literal: true

class User < ApplicationRecord
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable
  has_many :feedbacks
  has_many :ind_feedbacks
  has_many :links
  has_many :presentations, through: :links

  validates :fname, presence: true, length: { maximum: 50 }
  validates :lname, presence: true, length: { maximum: 50 }

  # Validation for correct email format

  EMAIL_FORMAT = /\A[\w+\-.]+@[a-z\d\-.]+\.[a-z]+\z/i.freeze
  validates :email, presence: true, format: { with: EMAIL_FORMAT }
  before_save { self.email = email.downcase }

  after_initialize :init

  VALID_EMAIL = INFO['admin'] + INFO['student'] + INFO['instructor']

  validates :email, inclusion: { in: VALID_EMAIL, message: :invalid }

  # initialize new user permissions
  def init
    if INFO['admin'].include? email
      self.perm = 0

    elsif INFO['instructor'].include? email
      self.perm = 1

    elsif INFO['student'].include? email
      self.perm = 2
    end
  end

  # Returns full name
  def full_name
    "#{fname} #{lname}"
  end
end
