# frozen_string_literal: true

class PresentationsController < ApplicationController
  # GET /presentations
  # GET /presentations.json
  def index
    @presentations = Presentation.all
  end

  # GET /presentations/1
  # GET /presentations/1.json
  def show; 
  end

   # GET /presentations/new
  def new
    @presentation = Presentation.new
  end

  # POST /presentations
  # POST /presentations.json
  def create
    @presentation = Presentation.new(presentation_params)
    if @presentation.save
      redirect_to presentations_url
    else
      render 'new'
    end
  end

  # GET /presaentations/1/edit
  def edit
    @presentation = Presentation.find(params[:id])
  end


  # PATCH/PUT /presentations/1
  # PATCH/PUT /presentations/1.json
  def update
    @presentation = Presentation.find(params[:id])
    if @presentation.update(presentation_params)
      flash[:success] = 'Profile updated'
      redirect_to page_path('home')
    else
      flash[:failure] = 'Error'
      redirect_to root_path
    end
  end

  # DELETE /presentations/1
  # DELETE /presentations/1.json
  def destroy
    @presentation = Presentation.find(params[:id])
    @presentation.destroy
    redirect_to presentations_url
  end

  private

  # Only allow a list of trusted parameters through.
  def presentation_params
    params.require(:presentation).permit(:name, user_ids: [])
  end
end
