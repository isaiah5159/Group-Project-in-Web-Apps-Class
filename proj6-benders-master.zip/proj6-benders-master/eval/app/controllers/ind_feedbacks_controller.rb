# frozen_string_literal: true

class IndFeedbacksController < ApplicationController
  before_action :set_ind_feedback, only: %i[show edit update destroy]

  # GET /ind_feedbacks
  # GET /ind_feedbacks.json
  def index
    @ind_feedbacks = IndFeedback.all
    @user_id = params[:u]
  end

  # GET /ind_feedbacks/1
  # GET /ind_feedbacks/1.json
  def show; end

  # GET /ind_feedbacks/new
  def new
    @student_id = params[:u]
    @presentation_id = params[:p]
    @ind_feedback = IndFeedback.new
  end

  # GET /ind_feedbacks/1/edit
  def edit; end

  # POST /ind_feedbacks
  # POST /ind_feedbacks.json
  def create
    @ind_feedback = IndFeedback.new(ind_feedback_params)

    respond_to do |format|
      if @ind_feedback.save
        format.html { redirect_to @ind_feedback, notice: 'Ind feedback was successfully created.' }
        format.json { render :show, status: :created, location: @ind_feedback }
      else
        format.html { render :new }
        format.json { render json: @ind_feedback.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /ind_feedbacks/1
  # PATCH/PUT /ind_feedbacks/1.json
  def update
    respond_to do |format|
      if @ind_feedback.update(ind_feedback_params)
        format.html { redirect_to @ind_feedback, notice: 'Ind feedback was successfully updated.' }
        format.json { render :show, status: :ok, location: @ind_feedback }
      else
        format.html { render :edit }
        format.json { render json: @ind_feedback.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /ind_feedbacks/1
  # DELETE /ind_feedbacks/1.json
  def destroy
    @ind_feedback.destroy
    respond_to do |format|
      format.html { redirect_to ind_feedbacks_url, notice: 'Ind feedback was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private

  # Use callbacks to share common setup or constraints between actions.
  def set_ind_feedback
    @ind_feedback = IndFeedback.find(params[:id])
  end

  # Only allow a list of trusted parameters through.
  def ind_feedback_params
    params.require(:ind_feedback).permit(:presentation_id, :user_id, :presentation_organization, :presentation_visuals, :presentation_content, :presentation_delivery, :presentation_overall, :comments, :fscore, :student_id)
  end
end
