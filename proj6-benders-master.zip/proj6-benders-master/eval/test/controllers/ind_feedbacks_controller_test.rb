# frozen_string_literal: true

require 'test_helper'

class IndFeedbacksControllerTest < ActionDispatch::IntegrationTest
  test 'should get index' do
    get ind_feedbacks_url
    assert_response :success
  end
end
