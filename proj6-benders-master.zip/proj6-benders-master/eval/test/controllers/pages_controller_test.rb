# frozen_string_literal: true

require 'test_helper'

class PagesControllerTest < ActionDispatch::IntegrationTest
  test 'should get home' do
    get root_path
    assert_response :success
    assert_select 'title', 'Home | DogMe'
  end

  test 'should get contact' do
    get page_path('contact')
    assert_response :success
    assert_select 'title', 'Contact | DogMe'
  end

  test 'should get gradebook' do
    get page_path('gradebook')
    assert_response :success
    assert_select 'title', 'Gradebook | DogMe'
  end

  test 'should get dashboard' do
    get page_path('dashboard')
    assert_response :success
    assert_select 'title', 'Admin Dashboard | DogMe'
  end
end
