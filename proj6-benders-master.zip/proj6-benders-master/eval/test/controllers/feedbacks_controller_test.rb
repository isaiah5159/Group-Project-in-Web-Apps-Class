# frozen_string_literal: true

require 'test_helper'

class FeedbacksControllerTest < ActionDispatch::IntegrationTest
  test 'should get index' do
    get feedbacks_url
    assert_response :success
  end
end
